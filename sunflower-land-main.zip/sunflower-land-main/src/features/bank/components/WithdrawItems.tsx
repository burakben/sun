import { useActor } from "@xstate/react";
import React, { useContext, useEffect, useState } from "react";
import Decimal from "decimal.js-light";

import { Context } from "features/game/GameProvider";
import { Inventory, InventoryItemName } from "features/game/types/game";
import { ITEM_DETAILS } from "features/game/types/images";
import { shortAddress } from "features/hud/components/Address";
import { KNOWN_IDS } from "features/game/types";
import { getItemUnit } from "features/game/lib/conversion";

import { Button } from "components/ui/Button";
import { Box } from "components/ui/Box";

import player from "assets/icons/player.png";

import { toWei } from "web3-utils";
import { metamask } from "lib/blockchain/metamask";
import { canWithdraw } from "../lib/bankUtils";
import { getOnChainState } from "features/game/actions/visit";

interface Props {
  onWithdraw: (ids: number[], amounts: string[]) => void;
}
export const WithdrawItems: React.FC<Props> = ({ onWithdraw }) => {
  const { gameService } = useContext(Context);
  const [game] = useActor(gameService);

  const [isLoading, setIsLoading] = useState(true);
  const [inventory, setInventory] = useState<Inventory>({});
  const [selected, setSelected] = useState<Inventory>({});

  useEffect(() => {
    setIsLoading(true);

    const load = async () => {
      const { game: state } = await getOnChainState({
        id: game.context.state.id as number,
        farmAddress: game.context.state.farmAddress as string,
      });

      setInventory(state.inventory);
      setIsLoading(false);
    };

    setSelected({});
    load();
  }, []);

  const withdraw = () => {
    const ids = (Object.keys(selected) as InventoryItemName[]).map(
      (item) => KNOWN_IDS[item]
    );
    const amounts = (Object.keys(selected) as InventoryItemName[]).map((item) =>
      toWei(selected[item]?.toString() as string, getItemUnit(item))
    );

    onWithdraw(ids, amounts);
  };

  const onAdd = (itemName: InventoryItemName) => {
    setSelected((prev) => ({
      ...prev,
      [itemName]: (prev[itemName] || new Decimal(0)).add(1),
    }));

    setInventory((prev) => ({
      ...prev,
      [itemName]: prev[itemName]?.minus(1),
    }));
  };

  const onRemove = (itemName: InventoryItemName) => {
    setInventory((prev) => ({
      ...prev,
      [itemName]: (prev[itemName] || new Decimal(0)).add(1),
    }));

    setSelected((prev) => ({
      ...prev,
      [itemName]: prev[itemName]?.minus(1),
    }));
  };

  if (isLoading) {
    return <span className="text-shadow loading">Loading</span>;
  }

  const inventoryItems = (Object.keys(inventory) as InventoryItemName[]).filter(
    (item) => inventory[item]?.gt(0)
  );

  console.log({ inventoryItems });

  const selectedItems = (Object.keys(selected) as InventoryItemName[]).filter(
    (item) => selected[item]?.gt(0)
  );

  return (
    <>
      <span className="text-shadow text-base">Select items to withdraw</span>

      <div className="flex flex-wrap h-fit">
        {inventoryItems.map((itemName) => (
          <Box
            count={inventory[itemName]}
            // isSelected={selected.includes(itemName)}
            key={itemName}
            onClick={() => onAdd(itemName)}
            image={ITEM_DETAILS[itemName].image}
            locked={!canWithdraw({ item: itemName, game: game.context.state })}
          />
        ))}
        {/* Pad with empty boxes */}
        {inventoryItems.length < 4 &&
          new Array(4 - inventoryItems.length)
            .fill(null)
            .map((_, index) => <Box disabled key={index} />)}
      </div>

      <div className="mt-2">
        <span className="text-shadow text-base">Selected</span>

        <div className="flex flex-wrap h-fit mt-2">
          {selectedItems.map((itemName) => {
            return (
              <Box
                count={selected[itemName]}
                key={itemName}
                onClick={() => onRemove(itemName)}
                image={ITEM_DETAILS[itemName].image}
              />
            );
          })}
          {/* Pad with empty boxes */}
          {selectedItems.length < 4 &&
            new Array(4 - selectedItems.length)
              .fill(null)
              .map((_, index) => <Box disabled key={index} />)}
        </div>
      </div>

      <div className="flex items-center mt-2 mb-2">
        <img src={player} className="h-8 mr-2" />
        <div>
          <p className="text-shadow text-sm">Sent to your wallet</p>
          <p className="text-shadow text-sm">
            {shortAddress(metamask.myAccount || "XXXX")}
          </p>
        </div>
      </div>

      <Button onClick={withdraw} disabled={selectedItems.length <= 0}>
        Withdraw
      </Button>
      <span className="text-xs underline">
        <a
          href="https://docs.sunflower-land.com/fundamentals/withdrawing"
          target="_blank"
          rel="noreferrer"
        >
          Read more
        </a>
      </span>
    </>
  );
};
