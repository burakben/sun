export type Message = {
  id: string;
  title?: string;
  body: string;
  unread: boolean;
};
