import React from "react";

export const Withdrawing: React.FC = () => {
  return <span className="loading">Withdrawing</span>;
};
