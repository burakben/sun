const willowTree = require("./willow_tree.mp3");

export const playlist = [
  {
    name: "Willow tree",
    file: willowTree,
    artist: "Romy",
  },
];
